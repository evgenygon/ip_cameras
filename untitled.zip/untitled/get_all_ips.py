import requests
#take all ip from israel
r_ip_adresses = requests.get('https://lite.ip2location.com/israel-ip-address-ranges')
print(r_ip_adresses.status_code)

print(dir(r_ip_adresses))
print(r_ip_adresses.content)