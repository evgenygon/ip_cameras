import nmap
nm = nmap.PortScanner()
print('welcome\n')
real_ip = '93.172.132.200'
print(nm.scan(real_ip, '80'))
print('reason : ' + nm[real_ip].tcp(80)['reason'])
real_ip = '93.172.132.211'
print(nm.scan(real_ip, '80'))
print('reason : ' + nm[real_ip].tcp(80)['reason'])